import pyautogui
import time

# pip install pyperclip 回车
# pip install xlrd 回车
# pip install pyautogui==0.9.50 回车
# pip install opencv-python -i https://pypi.tuna.tsinghua.edu.cn/simple 回车
# pip install pillow 回车

# pyautogui库其他用法 https://blog.csdn.net/qingfengxd1/article/details/108270159
endimg = 'complicted.png'
nextimg = 'next.png'
conimg = 'continue.png'
pauimg = 'pause.png'
applyimg = 'apply.png'
waimg = 'wa.png'
def mainWork():
    flagstart=0
    wrongtime, t = 0, 0
    time.sleep(1)
    while pyautogui.locateCenterOnScreen('fanhuikecheng.png') is None:
        print('请回到学习页面')
        flagstart=1
        time.sleep(1)
    if flagstart==1:
        pyautogui.press('f5')
        time.sleep(1)
    pyautogui.click(755, 797, clicks=1, 
                    interval=0.2, duration=0.2, button='left')
    print('点击中间播放键')
    pyautogui.scroll(int(-100))
    print('滚动鼠标一点点')
    while True:
        print('扫描屏幕')
        endposi = pyautogui.locateCenterOnScreen(endimg, confidence=0.9)
        if endposi is not None:
            print('发现任务以完成图标')
            break
        pauseposi = pyautogui.locateCenterOnScreen(pauimg, confidence=0.9)
        if pauseposi is not None:
            pyautogui.click(pauseposi.x, pauseposi.y, clicks=1,
                            interval=0.2, duration=0.2, button='left')
            time.sleep(0.5)
        ap = pyautogui.locateCenterOnScreen('a.png', confidence=0.9)
        bp = pyautogui.locateCenterOnScreen('b.png', confidence=0.9)
        cp = pyautogui.locateCenterOnScreen('c.png', confidence=0.9)
        dp = pyautogui.locateCenterOnScreen('d.png', confidence=0.9)
        if ap and bp:
            if cp:
                if dp:
                    ans = t % 4
                else:
                    ans = t % 3
            else:
                ans = t % 2
            t += 1
            if ans == 0:
                pyautogui.click(ap.x, ap.y, clicks=1,
                                interval=0.2, duration=0.2, button='left')
            elif ans == 1:
                pyautogui.click(bp.x, bp.y, clicks=1,
                                interval=0.2, duration=0.2, button='left')
            elif ans == 2:
                pyautogui.click(cp.x, cp.y, clicks=1,
                                interval=0.2, duration=0.2, button='left')
            elif ans == 3:
                pyautogui.click(dp.x, dp.y, clicks=1,
                                interval=0.2, duration=0.2, button='left')
            time.sleep(1)
            applyposi = pyautogui.locateCenterOnScreen(
                applyimg, confidence=0.9)
            if applyposi is not None:
                print('没有提交键,等待中')
                applyposi = pyautogui.locateCenterOnScreen(
                    applyimg, confidence=0.9)
                time.sleep(1)
            pyautogui.click(applyposi.x, applyposi.y, clicks=1,
                            interval=0.2, duration=0.2, button='left')
            time.sleep(2)
            waposi = pyautogui.locateCenterOnScreen(waimg, confidence=0.9)
            if waposi and wrongtime < 3:
                pyautogui.press('f5')
                print('答案错误，刷新页面(3s)')
                time.sleep(3)
                pyautogui.click(755, 797, clicks=1,
                                interval=0.2, duration=0.2, button='left')
                wrongtime += 1
                continue
            conposi = pyautogui.locateCenterOnScreen(conimg, confidence=0.9)
            if conposi:
                pyautogui.click(conposi.x, conposi.y, clicks=1,
                                interval=0.2, duration=0.2, button='left')
        time.sleep(5)

    pyautogui.scroll(int(-2000))
    print('滚动鼠标到底部')
    time.sleep(2)
    nextposi = pyautogui.locateCenterOnScreen(nextimg, confidence=0.5)
    while nextposi is None:
        print('没有下一页按钮')
        nextposi = pyautogui.locateCenterOnScreen(nextimg, confidence=0.5)
    pyautogui.click(nextposi.x, nextposi.y, clicks=1,
                    interval=0.2, duration=0.2, button='left')
    print('点击下一章')
    time.sleep(2)
    print('等待脚本刷题ing')
    sec = 0
        
    while pyautogui.locateCenterOnScreen('wancheng.png', confidence=0.9) is None:
        if pyautogui.locateCenterOnScreen('waiting.png', confidence=0.9) is None:
            # print('完成')
            break
        print('等待脚本刷题%d' % sec)
        sec += 1
        time.sleep(1)
    print('脚本刷题完成')
    pyautogui.scroll(int(-5000))
    print('滚动鼠标到底部')
    time.sleep(2)
    nextposi = pyautogui.locateCenterOnScreen(nextimg, confidence=0.9)
    pyautogui.click(nextposi.x, nextposi.y, clicks=1,
                    interval=0.2, duration=0.2, button='left')
    print('点击下一章')


if __name__ == '__main__':
    print('开始(3s后开始)')
    time.sleep(3)
    # print(pyautogui.position().x,pyautogui.position().y)
    while True:
        mainWork()
        time.sleep(0.1)
        print("等待0.1秒")
