#include <bits/stdc++.h>
int lexical();